package com.agrichain.model;

public class Crop {
    private String name;
    private String type;
    private int maturityDays;

    public Crop(String name, String type, int maturityDays) {
        this.name = name;
        this.type = type;
        this.maturityDays = maturityDays;
    }

    public String getCropName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public int getMaturityDays() {
        return maturityDays;
    }
}