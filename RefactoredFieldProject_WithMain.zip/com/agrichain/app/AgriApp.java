package com.agrichain.app;

import com.agrichain.model.Crop;
import com.agrichain.refactored.*;

public class AgriApp {
    public static void main(String[] args) {
        Crop wheat = new Crop("Wheat", "Rabi", 120);
        RefactoredField field = new RefactoredField(1.0, wheat, "Loamy");

        FieldEvaluator soilEvaluator = new SoilSuitabilityEvaluator();
        FieldEvaluator sizeEvaluator = new SmallFieldEvaluator();

        if (soilEvaluator.evaluate(field)) {
            System.out.println("Field is suitable based on soil type.");
        } else {
            System.out.println("Field is NOT suitable based on soil type.");
        }

        if (sizeEvaluator.evaluate(field)) {
            System.out.println("Field is considered small.");
        } else {
            System.out.println("Field is large.");
        }
    }
}