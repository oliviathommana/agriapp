package com.agrichain.refactored;

public class SoilSuitabilityEvaluator implements FieldEvaluator {

    @Override
    public boolean evaluate(RefactoredField field) {
        return "Loamy".equalsIgnoreCase(field.getSoilType());
    }
}