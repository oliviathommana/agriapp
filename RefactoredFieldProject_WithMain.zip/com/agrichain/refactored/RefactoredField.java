package com.agrichain.refactored;

import com.agrichain.model.Crop;

public class RefactoredField {
    private double sizeInAcres;
    private Crop crop;
    private String soilType;

    public RefactoredField(double sizeInAcres, Crop crop, String soilType) {
        this.sizeInAcres = sizeInAcres;
        this.crop = crop;
        this.soilType = soilType;
    }

    public double getSizeInAcres() {
        return sizeInAcres;
    }

    public Crop getCrop() {
        return crop;
    }

    public String getSoilType() {
        return soilType;
    }
}