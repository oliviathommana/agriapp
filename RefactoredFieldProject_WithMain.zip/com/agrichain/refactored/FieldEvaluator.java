package com.agrichain.refactored;

public interface FieldEvaluator {
    boolean evaluate(RefactoredField field);
}