package com.agrichain.refactored;

public class SmallFieldEvaluator implements FieldEvaluator {

    @Override
    public boolean evaluate(RefactoredField field) {
        return field.getSizeInAcres() < 1.5;
    }
}