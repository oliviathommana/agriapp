package com.agrichain.strategy;

import com.agrichain.model.Field;

/**
 * Strategy Layer: Checks if the field's soil type is Loamy.
 */
public class SoilSuitabilityEvaluator implements FieldEvaluator {
    @Override
    public boolean evaluate(Field field) {
        return "Loamy".equalsIgnoreCase(field.getSoilType());
    }
}