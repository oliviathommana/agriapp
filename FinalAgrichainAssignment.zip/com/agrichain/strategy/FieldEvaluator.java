package com.agrichain.strategy;

import com.agrichain.model.Field;

/**
 * Strategy Layer: Interface for evaluating field conditions.
 */
public interface FieldEvaluator {
    boolean evaluate(Field field);
}