package com.agrichain.model;

/**
 * Domain Layer: Represents a field containing a crop and soil details.
 */
public class Field {
    private double sizeInAcres;
    private Crop crop;
    private String soilType;

    public Field(double sizeInAcres, Crop crop, String soilType) {
        this.sizeInAcres = sizeInAcres;
        this.crop = crop;
        this.soilType = soilType;
    }

    public double getSizeInAcres() {
        return sizeInAcres;
    }

    public Crop getCrop() {
        return crop;
    }

    public String getSoilType() {
        return soilType;
    }
}