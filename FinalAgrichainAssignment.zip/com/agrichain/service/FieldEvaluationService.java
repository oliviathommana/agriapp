package com.agrichain.service;

import com.agrichain.model.Field;
import com.agrichain.strategy.FieldEvaluator;

/**
 * Service Layer: Applies business logic to field evaluation.
 */
public class FieldEvaluationService {
    public boolean evaluate(Field field, FieldEvaluator evaluator) {
        return evaluator.evaluate(field);
    }
}