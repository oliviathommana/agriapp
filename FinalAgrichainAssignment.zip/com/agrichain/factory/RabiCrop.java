package com.agrichain.factory;

import com.agrichain.model.Crop;

/**
 * Factory Layer: Creates Rabi type crops using CropFactory interface.
 */
public class RabiCrop implements CropFactory {
    @Override
    public Crop createCrop(String name, String type, int maturityDays) {
        return new Crop(name, type, maturityDays);
    }
}