package com.agrichain.factory;

import com.agrichain.model.Crop;

/**
 * Factory Layer: Interface for crop creation.
 */
public interface CropFactory {
    Crop createCrop(String name, String type, int maturityDays);
}